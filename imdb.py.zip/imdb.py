# _*_ coding: utf-8 _*_
from bs4 import BeautifulSoup
from  requests import get
import pandas as pd
from pandas import DataFrame
import re


#scrapping  the link of 250 top imdb rated movies

url='http://www.imdb.com/chart/top'
response=get(url)

html_soup=BeautifulSoup(response.text,'html.parser')
movie_container=html_soup.find_all('td',class_='titleColumn')
movie_link=[]
for containers in movie_container:
	link=str(containers.a)
	link=link.split('"')
	movie_link.append("https://www.imdb.com"+str(link[1]))	

title=[]
year=[]
imdb_rating=[]
no_reviewers=[] # number of reviewers
length=[]
genre1=[]
genre2=[]
genre3=[]
genre4=[]
r_date=[] # release date
summary=[]
director=[]
writer1=[]
writer2=[]
writer3=[]
star1=[]
star2=[]
star3=[]
star4=[]
star5=[]
plot_k_list=[] # plot keyword list
budget=[]
gross_usa=[]
c_ww_gross=[] # cumulative worlwide gross
prod_c=[] # production company


for items in movie_link:
	url=items
	response=get(url)
	html_soup=BeautifulSoup(response.text,'html.parser')
		
	# movie title
	m_title=(html_soup.find('div',class_='title_wrapper').h1.text)
	m_title=m_title.split('(')[0]
	title.append(m_title)
	
	# year
	m_year=(html_soup.find('div',class_='title_wrapper').h1.span.text)
	m_year=re.sub('[(,)]','',m_year)
	year.append(m_year)
	
	# imdb rating
	m_imdb=(html_soup.find('div',class_='ratingValue').strong.span.text)
	imdb_rating.append(m_imdb)
	
	# Number of reviewers
	m_no_rev=(html_soup.find('div',class_='imdbRating').a.span.text)
	m_no_rev=re.sub('\ {2}','',m_no_rev)
	no_reviewers.append(m_no_rev)
	
	# story summary
	m_summary=(html_soup.find('div',class_='summary_text').text)
	m_summary=re.sub('\ {2,}','',m_summary)
	m_summary=re.sub('\n','',m_summary)
	summary.append(m_summary)
	
	# length
	m_len=(html_soup.find('div',class_='title_wrapper'))
	m_len=(m_len.find('div',class_='subtext').time.text)
	m_len=re.sub('\ {2}','',m_len)
	m_len=re.sub('\n','',m_len)
	length.append(m_len)
	
	# budget
	count=0
	for h4 in html_soup.find_all('h4'):
		if "Budget:" in h4:
			budget.append(h4.next_sibling.strip())
			count=count+1
	if count==0:
		budget.append(" ")
	
	#gross usa
	count1=0	
	for h4 in html_soup.find_all('h4'):
		if "Gross USA:" in h4:
			obj=h4.next_sibling.strip()
			obj=re.sub('[,]$','',obj)
			gross_usa.append(obj)
			count1=count1+1
	if count1==0:
		gross_usa.append(" ")

	# cumulative world wide gross
	count2=0
	for h4 in html_soup.find_all('h4'):
		if "Cumulative Worldwide Gross:" in h4:
			obj1=(h4.next_sibling.strip())
			obj1=re.sub('[,]$','',obj1)
			c_ww_gross.append(obj1)
			count2=count2+1

	if count2==0:
		c_ww_gross.append(" ")	
		
	# director
	m_dir=html_soup.find_all('div',class_="credit_summary_item")
	director.append(m_dir[0].a.text)

	# writer
	w_list=[" "," "," "]
	m_wri=html_soup.find_all('div',class_="credit_summary_item")
	m=m_wri[1].find_all('a')
	for item in range(len(m)):
		w_list[item]=m[item].text
		w_list[item]=re.sub('.*more credit[s]*',' ',m[item].text)
	writer1.append(w_list[0])
	writer2.append(w_list[1])
	writer3.append(w_list[2])
	
	# stars
	s_list=[" "," "," "," "," "]
	m_star=html_soup.find_all('div',class_="credit_summary_item")
	m=m_star[2].find_all('a')
	for item in range(len(m)):
		s_list[item]=m[item].text
		s_list[item]=re.sub('See full cast & crew',' ',m[item].text)
	star1.append(s_list[0])
	star2.append(s_list[1])
	star3.append(s_list[2])
	star4.append(s_list[3])
	star5.append(s_list[4])

	# release date
	rel_d=html_soup.find('div',class_='subtext')
	r=rel_d.find_all('a')
	r=(r[-1].text)
	r=re.sub('\n','',r)
	r_date.append(r)

	# genre
	g_list=[" "," "," "," "]
	m_genre=html_soup.find('div',class_='subtext')
	g=m_genre.find_all('a')
	del g[-1]
	for item in range(len(g)):
		g_list[item]=g[item].text
	genre1.append(g_list[0])
	genre2.append(g_list[1])
	genre3.append(g_list[2])
	genre4.append(g_list[3])
		
	# plote keyword list
	k_list=[]
	pk_list=html_soup.find('div',class_="see-more inline canwrap")
	pk_list=pk_list.find_all('a')
	for item in range(len(pk_list)):
		k_list.append(pk_list[item].text)
	del k_list[-1]
	final_list=""
	for item in range(len(k_list)):
		final_list=(str(final_list)+str(k_list[item])+"|")
	plot_k_list.append(final_list)
	
	# production
	prod=html_soup.find_all('div',class_='article') 
	prod= html_soup.find_all('div',class_="txt-block")
	for items in range(len(prod)):
		if prod[items].h4:
			if (prod[items].h4.text)=="Production Co:":
				prod_c.append(prod[items].a.text)
				

# data feame column heading	
column=["Name","Link","Year","IMDB rating","Number of reviewers","Length","Genre 1","Genre 2","Genre 3","Genre 4","Release date","Story summary","Director","Writer 1","Writer 2","Writer 3","Star 1","Star 2","Star 3","Star 4","Star 5","Plot keyword list","Budget","Gross USA","Cumulative worldwide gross","Production Company"]

# combing all list to a dataframe and storing it into an csv file
movie_det=pd.DataFrame({"Name":title,"Link":link,"Year":year,"IMDB rating":imdb_rating,"Number of reviewers":no_reviewers,"Length":length,"Genre 1":genre1,"Genre 2":genre2,"Genre 3":genre3,"Genre 4":genre4,"Release date":r_date,"Story summary":summary,"Director":director,"Writer 1":writer1,"Writer 2":writer2,"Writer 3":writer3,"Star 1":star1,"Star 2":star2,"Star 3":star3,"Star 4":star4,"Star 5":star5,"Plot keyword list":plot_k_list,"Budget":budget,"Gross USA":gross_usa,"Cumulative worldwide gross":c_ww_gross,"Production Company":prod_c})

movie_det=movie_det.reindex(columns=column)
movie_det.to_csv('Movie details.csv',sep=',',index=False,encoding='utf-8-sig')
